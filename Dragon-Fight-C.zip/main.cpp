#include <iostream>
#include<unistd.h>
#include<random>
#include<stdlib.h>
#include<vector>
using namespace std;

/* cout: prints text
endl: is used to make a new line you can also use "\n"
to declare a variable you need to put its type first before giving it a name*/

/*Var Types:
string: self explanitory
int: for integers
double: stores floating point numbers ex: 19.99 4.6
char: a single character ex: 'a'
bool: stores either true or false
*/

int randNum; // Global Variable 

// random number generator
int randomValue(int num1, int num2) {
  random_device rd;
  uniform_int_distribution<int> dist(num1,num2);
  randNum = dist(rd);
  return randNum;
}


int main() { // the main code
  system("clear");
  int Hp,enemyhp,maxHp;
  maxHp = 40;
  Hp = 40;
  enemyhp = 50;

  int x = 1;

  // inventory
  vector<string>items;
  items.push_back("Greater Healing Potion");
  items.push_back("Healing Potion");
  items.push_back("Bread");

  bool fightover = false;
  bool win = false;
  
  
  cout << "Welcome to my game.\n";
  cout << "I hope you enjoy it.\n";
  sleep(2);
  system("clear");
  
  cout << "You are currently engaged in a fight with a dragon.\n";
  char option;
  int attack;
  int defence;
  int itemchoose;
  
  while (fightover == false) {
    
    cout << "\t\t\tHp: "<< Hp <<"\t\tEnemy Hp: "<<enemyhp << endl;
    cout << "\t\t\ta.Fight\t\tb.Defend\n\t\t\tc.Items\t\td.Die\n";
    cout << "What will you do: ";
    cin >> option;
    
    if (option == 'a') {
      
      attack = randomValue(1,12);
      cout << "\nYou deal " << attack << " damage to the dragon.\n";
      enemyhp -= attack;
      if (enemyhp <= 0) {
        fightover = true;
        cout << "You have defeated the dragon.";
      }
    } else if (option == 'b') {
      defence = randomValue(1,7);
    } else if (option == 'c') {
      
      for (auto i: items){ // for loop
        cout<< x << ". " << i << '\n';
        x += 1;
      }
      x = 1;
      
      cout << "What do you want to use: ";
      cin >> itemchoose;
      
      if (items[itemchoose-1] == "Greater Healing Potion"){
        Hp += 30;
        items.erase (items.begin()+(itemchoose-1));
        if (Hp >= maxHp){
          Hp = maxHp;
          cout << "\nYou heal to full health\n";
        } else {
          cout << "\nYou heal 30 hp\n";
        }
      } else if (items[itemchoose-1] == "Healing Potion"){
        Hp += 15;
        items.erase (items.begin()+(itemchoose-1));
        if (Hp >= maxHp){
          Hp = maxHp;
          cout << "\nYou heal full health\n";
        } else {
          cout << "\nYou heal 15 hp\n";
        }
      } else if (items[itemchoose-1] == "Bread"){
        Hp += 1;
        items.erase (items.begin()+(itemchoose-1));
        if (Hp >= maxHp){
          Hp = maxHp;
          cout << "\nYou heal full health\n";
        } else {
          cout << "\nYou heal 1 hp\n";
        }
          
      } else {
        cout << "\nYou can't use that.\n";
      }
        
    } else {
      cout << "You die.";
      sleep(1);
      cout <<"What did you expect";
      fightover = true;
    }
    if (fightover == false) {
      attack = randomValue(1,10);
      cout << "The dragon deals " << attack << " damage to you.\n";
      if (option == 'b') {
        defence -= attack;
        if (defence < 0){
          Hp += defence;
        }
        defence = 0;
      } else {
        Hp -= attack;
      }
      if (Hp <= 0) {
        fightover = true;
        cout << "You were defeated by the dragon.\nGameOver";
      }
      
    }
    sleep(2);
    system("clear");
      
  }
  return; // ends the code
}